package com.example.controller;


import com.example.dto.UserDto;
import com.example.service.UserService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static java.time.LocalDate.now;

@RestController
public class MyRestController {

    private UserService userService;

    public MyRestController(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping(value = "/abcd", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Map getDemo() {
        Map<String, String> map = new HashMap<>();
                map.put("a", "Hello World!");
        return map;
    }

    @RequestMapping(value = "/", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public void addUser(@RequestBody UserDto userDto) {
        userService.addUser(userDto);
    }
}

