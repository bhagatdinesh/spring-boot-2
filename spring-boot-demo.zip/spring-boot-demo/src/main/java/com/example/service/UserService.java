package com.example.service;

import com.example.dto.UserDto;
import com.example.entity.User;
import org.springframework.stereotype.Service;

public interface UserService {
    public void addUser(UserDto userDto);

    public User getUser();
}
