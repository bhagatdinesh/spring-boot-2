package com.example.service.impl;

import com.example.dao.UserDao;
import com.example.dto.UserDto;
import com.example.entity.User;
import com.example.service.UserService;
import org.springframework.stereotype.Service;

@Service("UserService")
public class UserServiceImpl implements UserService {

    private UserDao userDao;

    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public void addUser(UserDto userDto) {
        User user = new User();
        user.setFullName(userDto.getName());
        user.setDateOfBirth(userDto.getDateOfBirth());
        userDao.save(user);
    }

    @Override
    public User getUser() {
        return null;
    }
}
