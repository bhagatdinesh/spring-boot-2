
SET FOREIGN_KEY_CHECKS = 0; 
truncate test.user ;
truncate test.hibernate_sequence;
truncate test.comment;
truncate test.article;
truncate test.tag;
truncate test.article_tag;
SET FOREIGN_KEY_CHECKS = 1;
